Cretan Gheorghe-Cristian

Am rezolvat toate cerintele si de asemenea si bonusul.
Am implementat o lista dublu inlantuita, se putea face si cu una simplu inlantuita,
dar a fost mai lejer de implementat la cerinta 4 cu una dublu inlantuita si
de asta am facut alegerea asta. Functiile de inserare, stergere si sortare
a unei lista sunt destul de standar nu e nimic incredibil.
Task-urile sunt implementate urmarind cerintele..
A fost destul de naspa de urmarit leak-urile de memorie cu valgrind, dar
you figure it out pana la sfarsit. Despre implementare eu zic ca 
comentariile din sursa sunt suficiente. Ce se poate adauga e faptul ca
am facut pentru un "k" arbitrar fiecare cerinta pentru a da o functionalitate in plus.
In cazul schimbarii ferestrelor.

Feedback pentru tema:
Ideea temei este geniala, foarte smechera si o aplicabilitate buna a listelor.
Desi a fost scoasa cam repede si au existat probleme cu testele si etc si asta
a fost cam enervant, script-ul de python pt vizualizare din nou, era really
good practice la inceput, mi-a placut foarte mult.
